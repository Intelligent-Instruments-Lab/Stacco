Create a c++ project on BELA IDE
Open stacco_local.maxpat on the laptop, make sure to have nn~ (https://github.com/acids-ircam/nn_tilde) and one RAVE model in search path


